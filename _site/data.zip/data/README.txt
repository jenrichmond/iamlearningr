File: babynames.csv
Data source: ozbabynames package https://github.com/ropenscilabs/ozbabynames

File: Beall_Hofer_Schaller_Study1.csv
ResearchQ: Do Outbreaks of Infectious Diseases Influence Voting Behavior?
Original article: Beall, A. T., Hofer, M. K., & Shaller, M. (2016). Infections and elections: Did an Ebola outbreak influencethe 2014 U.S. federal elections (and if so, how)??Psychological Science, 27,?595-605.
Data source: Open Stats Lab https://sites.trinity.edu/osl/data-sets-and-activities/correlation-activities


File: crappy_internet.csv
ResearchQ: Is internet speed in lockdown worse when it rains?
Original article: na 
Data source: Google forms data www.tinyurl.com/howcrappyisyourinternet

File: my_favourite_things.csv
ResearchQ: In the Sound of Music, do people like food things better than non-food things? Is the number of times that people have seen The Sound of Music related to their trivia performance?
Original article: na
Data source: Google forms data https://forms.gle/6fMZa81xQ6XKqKoMA

File: penguin.csv
ResearchQ: Do the characteristics that best predict whether an Antarctic penguin in male or female differ across species?
Original article: Gorman KB, Williams TD, Fraser WR (2014) Ecological Sexual Dimorphism and Environmental Variability within a Community of Antarctic Penguins (Genus?Pygoscelis). PLoS ONE 9(3): e90081.
Data source: https://github.com/allisonhorst/penguins



File: ZhangStudy3.csv
Research Q: Do People Underestimate the Pleasure of Remembering Ordinary vs. Extraordinary Events?
Original article: Zhang, T., Kim, T., Brooks, A. W., Gino, F., & Norton, M. I. (2014). A "present" for the future: The unexpected value of rediscovery.?Psychological Science, 25,?1851-1860. 
Data source: Open Stats Lab https://sites.trinity.edu/osl/data-sets-and-activities/factorial-anova-activities







